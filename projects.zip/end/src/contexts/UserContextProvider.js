import {useState} from 'react'
import axios from 'axios';
import { compareSync } from 'bcryptjs';
import { userLoginContext } from './userLoginContext';
function UserContextProvider({children}) {

    let[currentUser,setCurrentUser]=useState({})
    let[userLoginStatus,setUserLoginStatus]=useState(false)
    let [error,setError]=useState('')

    async function onUserLogin(userCredObj) {
        let res = await axios.get(
          `http://localhost:4000/users?username=${userCredObj.username}`
        );
        let usersList = res.data;
    
        if (usersList.length === 0) {
          setError("Invalid Username");
        } else {
          let result = compareSync(userCredObj.password, usersList[0].password);
          if (result === false) {
            setError("Invalid Password");
          } else {
            setCurrentUser(usersList[0])
            setUserLoginStatus(true)
          }
        }
      }
  return (
    <div>
        <userLoginContext.Provider
        value={[currentUser,setCurrentUser,userLoginStatus,setUserLoginStatus,onUserLogin]}
        >{children}</userLoginContext.Provider>
    </div>
  )
}

export default UserContextProvider

