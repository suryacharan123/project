import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Navbar from "./components/navbar/Navbar";
import Loginform from "./components/loginform/Loginform";
import Register from "./components/register/Register";
import Home from "./components/home/Home";
import RoomList from "./components/roomlists/RoomList";
import Booking from "./components/search/Booking";
import HotelForm from './components/Hotelform/HotelForm' 
import Navbar from "./components/navbar/Navbar";
function App() {
  return (
    <div>

      <BrowserRouter>
      <Navbar></Navbar>

        <Routes>
          <Route path="/login" element={<Loginform />} />
          <Route path="/register" element={<Register></Register>}></Route>
          {/* Add a route for the root path */}
          <Route path="/" element={<Home/>} />
          <Route path="/booking" element={<Booking></Booking>}></Route>
          <Route path='/hotels' element={<HotelForm></HotelForm>}></Route>
          <Route path="/roomlist" element={<RoomList></RoomList>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
 
export default App;