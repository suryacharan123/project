import React, { useState,useContext,useEffect } from 'react'
import {useForm} from 'react-hook-form'
import './Loginform.css'
import { userLoginContext } from '../../contexts/userLoginContext';
import { useNavigate } from 'react-router-dom';
function Loginform() {
  let { register, handleSubmit } = useForm();
  let navigate = useNavigate();
  let [
    currentUser,
    setCurrentUser,
    userLoginStatus,
    setUserLoginStatus,
    onUserLogin,
  ] = useContext(userLoginContext);
  useEffect(() => {
    if (userLoginStatus === true) {
      navigate("/booking");
    }
   },[userLoginStatus]);

  console.log(userLoginStatus);
  return (
    <div>      
    <div className='bg'>
          <div className='login-container'>
      <h1 className="display-3 text-center text-info">User Login</h1>
 
      {/* {error.length!==0&&<p className="fs-2 text-center text-danger">{error}</p>} */}
      <form
       
        onSubmit={handleSubmit(onUserLogin)}
      >
        <div>
          <label htmlFor="username" className="form-label">
            Username
          </label>
          <input
            type="text"
            {...register("username")}
            className="form-control mb-4"
          />
        </div>
 
        {/* password */}
        <div>
          <label htmlFor="password" className="form-label">
            Password
          </label>
          <input
            type="password"
            {...register("password")}
            className="form-control mb-4"
          />
        </div>
 
        <button className="btn">Login</button>
      </form>
    </div>
    </div>
    </div>

  )
}
 
export default Loginform