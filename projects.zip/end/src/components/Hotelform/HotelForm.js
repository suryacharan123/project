import React, { useContext } from "react";
import {userLoginContext} from '../../contexts/userLoginContext'
import { useForm } from "react-hook-form";
import axios from "axios";
import "./HotelForm.css"; // Import your CSS file
 import { useNavigate } from "react-router-dom";
function HotelForm() {
  let navigate=useNavigate()
  const { register, handleSubmit, reset } = useForm();
  const [, , userLoginStatus] = useContext(userLoginContext);
 
  const onSubmit = async (data) => {
    try {
      // Send the form data to your server
      let response = await axios.post("http://localhost:4000/hotels", data);
 
      let savedHotel = response.data;
      console.log("Hotel saved:", savedHotel);
      alert("Thank you for registering your hotel");

      navigate('/booking')
      // Clear the form after successful submission
      reset();
    } catch (error) {
      console.error("Error submitting hotel form:", error);
    }
  };
 
  // Check if the user is logged in
  if (!userLoginStatus) {
    // If not logged in, display a message or redirect to login page
    return <p>Please log in to register your hotel.</p>;
  }
 
  // If logged in, render the hotel registration form
  return (
<div className="backimgs">
<div className="containers">
<h1 className="heads">Hotel Registration Form</h1>
<form onSubmit={handleSubmit(onSubmit)}>
<label className="labels">
            Hotel Name:
            <input className="inputs" type="text" {...register("hotelName", { required: true })} />
          </label>
          <br></br>
          <label className="labels">
            Location:
            <input className="inputs" type="text" {...register("location", { required: true })} />
          </label><br></br>

          <label className="labels">
            Contact Person:
            <input className="inputs"
              type="text"
              {...register("contactPerson", { required: true })}
            />
          </label><br></br>

          <label className="labels">
            Email:
            <input className="inputs" type="email" {...register("email", { required: true })} />
          </label><br></br>

          <label className="labels">
            Phone:
            <input className="inputs" type="tel" {...register("phone", { required: true })} />
          </label><br></br>

          <label className="labels">
            Number of Rooms:
            <input className="inputs"
              type="number"
              {...register("numberOfRooms", { required: true })}
            />
          </label><br></br>

          <label className="labels">
            Price Per Night:
            <input className="inputs" type="number" {...register("pricePerNight", { required: true })} />
          </label><br></br>

          <label className="labels">
            Facilities:
            <textarea className="inputs" {...register("facilities")} rows="4"></textarea>
          </label><br></br>
<button className="btns" type="submit">Register Hotel</button>
</form>
</div>
</div>
  );
}
 
export default HotelForm;